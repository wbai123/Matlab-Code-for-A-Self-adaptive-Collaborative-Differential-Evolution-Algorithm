%%Installing MATPOWER 7.1 for testbed2

Step 1: From the folder matpower7.1 open install_matpower.m
Step 2: Run install_matpower.m in MATLAB
Step 3: When the installation asks to select a installation option in the MATPOWER Installation Options type option 3 and press Enter
Step 4: When the installation asks to run a few tests please say yes to check if everything is okay!

%%Enjoy this years' competition!
