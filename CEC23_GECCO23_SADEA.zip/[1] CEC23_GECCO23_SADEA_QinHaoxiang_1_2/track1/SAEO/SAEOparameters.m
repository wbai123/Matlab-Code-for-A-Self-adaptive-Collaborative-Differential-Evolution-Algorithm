
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
SAEOParameters.I_NP=1;
SAEOParameters.I_itermax= floor(5000/SAEOParameters.I_NP);%
SAEOParameters.F_weight=0.4;
SAEOParameters.F_CR=0.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%