%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SAEO Self-Adaptive Evolutionary Optimization Algorithm
% Author:           Haoxiang Qin, Wenlei Bai, Yi Xiang, Fangqing Liu, Yuyan Han, Ling Wang, and Kwang Y. Lee  
% Created Date:     Feb 9, 2023


function [Fit_and_p,FVr_bestmemit, fitMaxVector] = ...
    SAEO(SAEOParameters,caseStudyData,otherParameters,low_habitat_limit,up_habitat_limit)

%-----This is just for notational convenience and to keep the code uncluttered.--------
I_NP         = SAEOParameters.I_NP;
F_weight     = SAEOParameters.F_weight;
F_CR         = SAEOParameters.F_CR;
I_D          = numel(up_habitat_limit); %Number of variables or dimension
SAEOParameters.nVariables=I_D;
FVr_minbound = low_habitat_limit;
FVr_maxbound = up_habitat_limit;
I_itermax    = SAEOParameters.I_itermax;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fnc= otherParameters.fnc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%-----Check input variables---------------------------------------------

if ((F_CR < 0) || (F_CR > 1))
   F_CR=0.5;
   fprintf(1,'F_CR should be from interval [0,1]; set to default value 0.5\n');
end
if (I_itermax <= 0)
   I_itermax = 500;
   fprintf(1,'I_itermax should be > 0; set to default value 500\n');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fitMaxVector = zeros(1,I_itermax);

gen = 1; %iterations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%----parameters-----------------------------------------------------------
minPositionsMatrix = FVr_minbound;
maxPositionsMatrix= FVr_maxbound;
SAEOParameters.minPositionsMatrix=minPositionsMatrix; 
SAEOParameters.maxPositionsMatrix=maxPositionsMatrix;

% generate initial population.
rand('state',otherParameters.iRuns) %Guarantee same initial population
FM_pop = unifrnd(minPositionsMatrix,maxPositionsMatrix,I_NP,I_D);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------Evaluate the best member after initialization----------------------

[S_val, ~,~]=feval(fnc,FM_pop,caseStudyData,otherParameters);
[~,I_best_index] = min(S_val); 
FVr_bestmemit = FM_pop;

fitMaxVector(1,gen) = S_val(I_best_index);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SAEO
    F_weight_old=repmat(F_weight,I_NP,3);
    F_weight= F_weight_old;
    F_CR_old=repmat(F_CR,I_NP,1);
    F_CR=F_CR_old;    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
count = 0;
PopSize = 3;
Pops = initializePops(minPositionsMatrix,maxPositionsMatrix,PopSize);

Ex_count = 1;
External = zeros(8,I_D);
External_value = zeros(8,1);

while gen<I_itermax 

    other.a=(I_itermax-gen)/I_itermax;
    other.lowerlimit=FVr_minbound; %lower limit of the problem
    other.upperlimit = FVr_maxbound; %upper limit of the problem
    
    value_R=rand(I_NP,3);
    ind1=value_R<0.1;
    ind2=rand(I_NP,1)<0.1;
    F_weight(ind1)=0.1+rand(sum(sum(ind1)),1)*0.9;
    F_weight(~ind1)=F_weight_old(~ind1);
    F_CR(ind2)=rand(sum(ind2),1);
    F_CR(~ind2)=F_CR_old(~ind2); 
    
    if count < 6
        
        FM_pm1 = genpop(I_NP,I_D,minPositionsMatrix,maxPositionsMatrix);             % shuffled population 1
        FM_pm2 = genpop(I_NP,I_D,minPositionsMatrix,maxPositionsMatrix);             % shuffled population 2
        FM_pm3 = genpop(I_NP,I_D,minPositionsMatrix,maxPositionsMatrix);             % shuffled population 3 

    elseif count < 11 && count> 5
        Integer = randperm(5);
        FM_pm1 = External(Integer(1),:);
        FM_pm2 = External(Integer(2),:);
        FM_pm3 = External(Integer(3),:);
     
    else
        FM_pm1 = Pops(1,:);
        FM_pm2 = Pops(2,:);
        FM_pm3 = Pops(3,:);

    end
    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [FM_ui,~]=generate_trial(F_weight, F_CR, FM_pop, FVr_bestmemit,I_NP, I_D, minPositionsMatrix,FM_pm1,FM_pm2,FM_pm3,count);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

    %% Boundary Control
    FM_ui=update(FM_ui,minPositionsMatrix,maxPositionsMatrix);

    %Evaluation of new Pop
    S_val_temp=feval(fnc,FM_ui,caseStudyData,otherParameters);
    
    
    %% Elitist Selection
    ind=find(S_val_temp<S_val);
    if ind ~= 0
        S_val(ind)=S_val_temp(ind);
        FM_pop(ind,:)=FM_ui(ind,:);
        count = 0;
        if Ex_count < 2
            External(Ex_count,:) = FM_ui(ind,:);
            External_value(Ex_count) = S_val(ind);
            Ex_count = Ex_count + 1;
        else
            [~,I_worst_index] = max(External_value); 
            External(I_worst_index,:) = FM_ui(ind,:); 
            External_value(I_worst_index) = S_val(ind);
        end
        
    else
        count = count + 1;
    end
    

      
    %% update best results
    [S_bestval,I_best_index] = min(S_val);
    FVr_bestmemit = FM_pop(I_best_index,:); % best member of current iteration
    fitMaxVector(1,gen) = S_bestval;
 
     
    F_weight_old(ind,:)=F_weight(ind,:);
    F_CR_old(ind)=F_CR(ind);
     
    
    if ismember(I_best_index,ind)
        fitMaxVector(:,gen)= S_val(I_best_index);
    elseif gen>1
        fitMaxVector(:,gen)=fitMaxVector(:,gen-1);
    end
    
    fprintf('Fitness value: %f\n',fitMaxVector(1,gen))
    fprintf('Generation: %d\n',gen)
    
    gen=gen+1;
    %% store fitness evolution and obj fun evolution as well
    fitMaxVector(1,gen)=S_bestval;

end 

Fit_and_p=[fitMaxVector(1,gen) 0]; %;p2;p3;p4]


% VECTORIZED THE CODE INSTEAD OF USING FOR
function pop=genpop(a,b,lowMatrix,upMatrix)
pop=unifrnd(lowMatrix,upMatrix,a,b);

% VECTORIZED THE CODE INSTEAD OF USING FOR
function p=update(p,lowMatrix,upMatrix)
        [idx] = find(p<lowMatrix);
        p(idx)=lowMatrix(idx);
        [idx] = find(p>upMatrix);
        p(idx)=upMatrix(idx);



function Pops = initializePops(FVr_minbound,FVr_maxbound,PopSize)
    ws = length(FVr_minbound);
    Pops = nan(PopSize,ws);
    for j=1:ws
       range = FVr_maxbound(j) - FVr_minbound(j);
       for i=1:PopSize 
          Pops(i,j) = FVr_minbound(j) + ( range / (PopSize - 1.0) * (i-1.0));        
       end
       
       if (Pops(i,j)>FVr_maxbound(j))
           Pops(PopSize,j) = FVr_maxbound(j);
       end
       
   end


function [FM_ui,msg]=generate_trial(F_weight, F_CR, FM_pop, FVr_bestmemit,I_NP,I_D,minPositionsMatrix,FM_pm1,FM_pm2,FM_pm3,count)
    
    FM_popold = FM_pop;                  % save the old population
   
    FM_mui = rand(I_NP,I_D) < F_CR;  % all random numbers < F_CR are 1, 0 otherwise
    FM_mpo = FM_mui < 0.9;    % inverse mask to FM_mui


    FM_bm=FVr_bestmemit;

     if count > 7
            FM_ui = minPositionsMatrix + repmat(F_weight(:,1),1,I_D).*(-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2 + FM_pm3 - FM_pm2);
     else
        if(rand(0,1) < 0.4)
            FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(repmat(F_weight(:,2),1,I_D)+randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
        else
            FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(repmat(F_weight(:,2),1,I_D)+randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2 + FM_pm3 - FM_pm2);
        end    
     end
        FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
        msg=' SAEO/current-to-best/1';


    
return

  
