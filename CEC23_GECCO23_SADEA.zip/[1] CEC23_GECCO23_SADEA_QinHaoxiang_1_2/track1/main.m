clc;clear all;close all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GECAD GECCO and WCCI 2023 Competition: Evolutionary Computation in the Energy Domain: Risk-based Energy Scheduling
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
addpath('functions') %Necessary functions to run the algorithms (encrypted)
tTotalTime=tic; % lets track total computational time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Select testbed
Select_testbed=1; 
%Testbed 1: Risk-based energy scheduling
%Testbed 2: Transmission expansion planning

DB=Select_testbed;
% 1: Case study testbed 1
% 2: Case study testbed 2

Select_algorithm=2;
%1: HyDE algorithm (test algorithm)
%2: Your algorithm

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load MH parameters (e.g., get MH parameters from DEparameters.m file)
switch Select_algorithm
       case 1
          addpath('HyDE')
          algorithm='HyDE-Algorithm'; %'The participants should include their algorithm here'
          DEparameters %Function defined by the participant
          No_solutions=SAEOParameters.I_NP; %Notice that some algorithms are limited to one individual
       case 2
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          %%%%%%%%%%%%%%%%%%%%%% Your algorithm %%%%%%%%%%%%%%%%%%%%%%%%%%%
          addpath('SAEO')
          algorithm='SAEO-Algorithm'; %'The participants should include their algorithm here'
          SAEOparameters %Function defined by the participant
          No_solutions=SAEOParameters.I_NP;
        
        otherwise
          fprintf(1,'No algorithm selected\n');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load Data base 
[caseStudyData, DB_name]=callDatabase(DB);
noRuns=20; %this can be changed but final results should be based on 20 trials

%% Label of the algorithm and the case study
Tag.algorithm=algorithm;
Tag.DB=DB_name;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Set other parameters
otherParameters =setOtherParameters(caseStudyData, No_solutions, Select_testbed);
otherParameters.one = setOtherParameters(caseStudyData,1, Select_testbed);
%% Set lower/upper bounds of variables 
[lowerB,upperB] = setVariablesBounds(caseStudyData,otherParameters, Select_testbed);
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Call the MH for optimizationclear 
ResDB=struc([]);
for iRuns=1:noRuns %Number of trails
    tOpt=tic;
    rand('state',sum(noRuns*100*clock))% ensure stochastic indpt trials
    otherParameters.iRuns=iRuns;      
        
    switch Select_algorithm
        case 1
            [ResDB(iRuns).Fit_and_p, ...
            ResDB(iRuns).sol, ...
            ResDB(iRuns).fitVector]= ...                    
            HyDE(deParameters,caseStudyData,otherParameters,lowerB,upperB);  
        case 2     
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          %%%%%%%%%%%%%%%%%%%%%% Your algorithm %%%%%%%%%%%%%%%%%%%%%%%%%%%
            [ResDB(iRuns).Fit_and_p, ...
            ResDB(iRuns).sol, ...
            ResDB(iRuns).fitVector]= ...                    
            SAEO(SAEOParameters,caseStudyData,otherParameters,lowerB,upperB);

    end 
            
        ResDB(iRuns).tOpt=toc(tOpt); % time of each trial
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Save the results and stats
        Save_results
        
end


tTotalTime=toc(tTotalTime); %Total time