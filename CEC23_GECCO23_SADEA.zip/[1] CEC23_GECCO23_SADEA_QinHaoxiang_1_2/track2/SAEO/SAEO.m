%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SAEO
% Author:           Haoxiang Qin, Wenlei Bai, Yi Xiang, Fangqing Liu, Yuyan Han, Ling Wang, and Kwang Y. Lee     
% 
% Created Date:     Feb 9, 2023

function [Fit_and_p,FVr_bestmemit, fitMaxVector] = ...
    SAEO(deParameters,caseStudyData,otherParameters,low_habitat_limit,up_habitat_limit)

%-----This is just for notational convenience and to keep the code uncluttered.--------
I_NP         = deParameters.I_NP;
F_weight     = deParameters.F_weight;
F_CR         = deParameters.F_CR;
I_D          = numel(up_habitat_limit); %Number of variables or dimension
deParameters.nVariables=I_D;
FVr_minbound = low_habitat_limit;
FVr_maxbound = up_habitat_limit;
I_itermax    = deParameters.I_itermax;

%Repair boundary method employed
BRM = deParameters.I_bnd_constr; %1: bring the value to bound violated
                               %2: repair in the allowed range

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fnc= otherParameters.fnc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%-----Check input variables---------------------------------------------
if (I_NP < 5)
   I_NP=1;
   fprintf(1,' I_NP increased to minimal value 5\n');
end
if ((F_CR < 0) || (F_CR > 1))
   F_CR=0.5;
   fprintf(1,'F_CR should be from interval [0,1]; set to default value 0.5\n');
end
if (I_itermax <= 0)
   I_itermax = 500;
   fprintf(1,'I_itermax should be > 0; set to default value 500\n');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fitMaxVector = zeros(1,I_itermax);

gen = 1; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

minPositionsMatrix = FVr_minbound;
maxPositionsMatrix= FVr_maxbound;
deParameters.minPositionsMatrix=minPositionsMatrix; 
deParameters.maxPositionsMatrix=maxPositionsMatrix;

rand('state',otherParameters.iRuns) %Guarantee same initial population

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------Evaluate the best member after initialization----------------------
n = 100;

 for i=1:n
     FM_pop2(i,:) = unifrnd(minPositionsMatrix,maxPositionsMatrix,1,I_D);
 end       
[S_val2, ~,~]=feval(fnc,FM_pop2,caseStudyData,otherParameters);
fitness = sortrows([ (1:n)' S_val2(:, 1) ], 2);
globalBestFitness = fitness(1,2);

FVr_bestmemit = FM_pop2(fitness(1,1),:);
FM_pop = FVr_bestmemit;
fitMaxVector(1,gen)= globalBestFitness;
S_val = globalBestFitness;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SAEO
    F_weight_old=repmat(F_weight,I_NP,3);
    F_weight= F_weight_old;
    F_CR_old=repmat(F_CR,I_NP,1);
    F_CR=F_CR_old;    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
count = 0;

while gen<I_itermax-n  %%&&  fitIterationGap >= threshold
    %a = itr / MaxItr; % a value for gammaincinv function
    other.a=(I_itermax-gen)/I_itermax;
    other.lowerlimit=FVr_minbound; %lower limit of the problem
    other.upperlimit = FVr_maxbound; %upper limit of the problem
    
    value_R=rand(I_NP,3);
    ind1=value_R<0.1;
    ind2=rand(I_NP,1)<0.1;
    F_weight(ind1)=0.1+rand(sum(sum(ind1)),1)*0.9;
    F_weight(~ind1)=F_weight_old(~ind1);
    F_CR(ind2)=rand(sum(ind2),1);
    F_CR(~ind2)=F_CR_old(~ind2);    
        
        FM_pm1 = genpop(I_NP,I_D,minPositionsMatrix,maxPositionsMatrix);             % shuffled population 1
        FM_pm2 = genpop(I_NP,I_D,minPositionsMatrix,maxPositionsMatrix);             % shuffled population 2
        FM_pm3 = genpop(I_NP,I_D,minPositionsMatrix,maxPositionsMatrix);             % shuffled population 3 

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [FM_ui,FM_base,~]=generate_trial(F_weight, F_CR, FM_pop, FVr_bestmemit,I_NP, I_D,other,minPositionsMatrix,maxPositionsMatrix,FM_pm1,FM_pm2,FM_pm3,count);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

    %% Boundary Control
    FM_ui=update(FM_ui,minPositionsMatrix,maxPositionsMatrix,BRM,FM_base);

    %Evaluation of new Pop
    S_val_temp=feval(fnc,FM_ui,caseStudyData,otherParameters);
    
    
    %% Elitist Selection
    ind=find(S_val_temp<S_val);
    if ind ~= 0
        S_val(ind)=S_val_temp(ind);
        FM_pop(ind,:)=FM_ui(ind,:);
        count = 0;        
    else
        %FM_pop(ind,:)=FM_ui(ind,:);
        count = count + 1;
    end
    

      
    %% update best results
    [S_bestval,I_best_index] = min(S_val);
    FVr_bestmemit = FM_pop(I_best_index,:); % best member of current iteration
    % store fitness evolution and obj fun evolution as well
    fitMaxVector(1,gen) = S_bestval;
    %S_bestval
    
     
    F_weight_old(ind,:)=F_weight(ind,:);
    F_CR_old(ind)=F_CR(ind);
     
    
    if ismember(I_best_index,ind)
        fitMaxVector(:,gen)= S_val(I_best_index);
    elseif gen>1
        fitMaxVector(:,gen)=fitMaxVector(:,gen-1);
    end
    
    fprintf('Fitness value: %f\n',fitMaxVector(1,gen))
    fprintf('Generation: %d\n',gen)
    
    gen=gen+1;
    %% store fitness evolution and obj fun evolution as well
    fitMaxVector(1,gen)=S_bestval;
    %S_bestval

end %---end while ((I_iter < I_itermax) ...
%p1=sum(Best_otherInfo.penSlackBusFinal);
Fit_and_p=[fitMaxVector(1,gen) 0]; %;p2;p3;p4]

% VECTORIZED THE CODE INSTEAD OF USING FOR
function pop=genpop(a,b,lowMatrix,upMatrix)
pop=unifrnd(lowMatrix,upMatrix,a,b);

function pop2=genpop2(a,b,lowMatrix,upMatrix)
pop2=unifrnd(lowMatrix,upMatrix,a,b);

% VECTORIZED THE CODE INSTEAD OF USING FOR
function p=update(p,lowMatrix,upMatrix,BRM,FM_base)
switch BRM
    case 1 %Our method
        %[popsize,dim]=size(p);
        [idx] = find(p<lowMatrix);
        p(idx)=lowMatrix(idx);
        [idx] = find(p>upMatrix);
        p(idx)=upMatrix(idx);
    case 2 %Random reinitialization
        [idx] = [find(p<lowMatrix);find(p>upMatrix)];
        replace=unifrnd(lowMatrix(idx),upMatrix(idx),length(idx),1);
        p(idx)=replace;
    case 3 %Bounce Back
      [idx] = find(p<lowMatrix);
      p(idx)=unifrnd(lowMatrix(idx),FM_base(idx),length(idx),1);
        [idx] = find(p>upMatrix);
      p(idx)=unifrnd(FM_base(idx), upMatrix(idx),length(idx),1);
end

function codes = initializeCodes(FVr_minbound,FVr_maxbound,codeSize)
    ws = length(FVr_minbound);
    codes = nan(codeSize,ws);
    for jjj=1:ws
       range = FVr_maxbound(jjj) - FVr_minbound(jjj);
       for iii=1:codeSize 
          codes(iii,jjj) = FVr_minbound(jjj) + ( range / (codeSize - 1.0) * (iii-1.0));        
       end
       
       if (codes(iii,jjj)>FVr_maxbound(jjj))
           codes(codeSize,jjj) = FVr_maxbound(jjj);
       end
       
   end

function [FM_ui,FM_base,msg]=generate_trial(F_weight, F_CR, FM_pop, FVr_bestmemit,I_NP,I_D,other,minPositionsMatrix,maxPositionsMatrix,FM_pm1,FM_pm2,FM_pm3,count)
    
    FM_popold = FM_pop;                  % save the old population
   
    FM_mui = rand(I_NP,I_D) < F_CR;  % all random numbers < F_CR are 1, 0 otherwise
    FM_mpo = FM_mui < 0.9;    % inverse mask to FM_mui

    FM_bm=FVr_bestmemit;

    FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(repmat(F_weight(:,2),1,I_D)+randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);     
    FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
    FM_base = FM_bm;
    msg=' SAEO6/current-to-best/1';
    
return






