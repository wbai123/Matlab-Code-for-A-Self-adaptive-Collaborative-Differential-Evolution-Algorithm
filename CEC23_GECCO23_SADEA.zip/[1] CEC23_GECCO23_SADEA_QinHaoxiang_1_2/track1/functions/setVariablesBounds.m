function [lowerBounds, upperBounds] = setVariablesBounds(caseStudyData,otherParameters,Select_testbed)

if Select_testbed==1    
    % aux calculations
    v2gMaxChargeTmp=caseStudyData(1).v2gData.v2gMaxCharge;
    v2gMaxChargeTmp(caseStudyData(1).v2gData.v2gBusNo==0)=0;
    v2gMaxDischargeTmp=caseStudyData(1).v2gData.v2gMaxDischarge;
    v2gMaxDischargeTmp(caseStudyData(1).v2gData.v2gBusNo==0)=0; 
    %v2gMaxDischargeTmp(:,:)=0; % uncomment for no V2G
    genPMin=caseStudyData(1).genData.genPMin;
    genPMin(:,otherParameters.genType1Id)=caseStudyData(1).genData.genPMax(:,otherParameters.genType1Id);

    %% Only sell is allowed in this part
    % lowerBounds =reshape([
    %     genPMin'; % generators active power
    %     %caseStudyData(1).genData.genQMin'; % generators reactive power
    %     zeros(size(genPMin,2),caseStudyData(1).parameterData.numPeriods);
    %     -v2gMaxDischargeTmp';
    %     caseStudyData(1).loadData.PReduce'*0; % same size , but zero
    %     -caseStudyData(1).storageData.stMaxDischarge';
    %     caseStudyData(1).marketData.sellPMin']...
    %     ,1,caseStudyData(1).parameterData.numPeriods*otherParameters.ids.idsMarket(end));

    %% sell and buy allowed is allowed in this part
    lowerBounds =reshape([
        genPMin'; % generators active power
        -caseStudyData(1).marketData.sellPMax';
        -v2gMaxDischargeTmp';
        %caseStudyData(1).genData.genQMin'; % generators reactive power
        zeros(size(genPMin,2),caseStudyData(1).parameterData.numPeriods);
        caseStudyData(1).loadData.PReduce'*0; % same size , but zero
        -caseStudyData(1).storageData.stMaxDischarge']...
        ,1,caseStudyData(1).parameterData.numPeriods*otherParameters.ids.idsStorage(end));

    upperBounds = reshape([
        caseStudyData(1).genData.genPMax';
        caseStudyData(1).marketData.sellPMax';
        v2gMaxChargeTmp';
        %caseStudyData(1).genData.genQMax';
        ones(size(genPMin,2),caseStudyData(1).parameterData.numPeriods);      
        caseStudyData(1).loadData.PReduce';
        caseStudyData(1).storageData.stMaxCharge']...; %market sell
        ,1,caseStudyData(1).parameterData.numPeriods*otherParameters.ids.idsStorage(end));

elseif Select_testbed==2
    % lower and upper bounds of the testbed 2
    lowerBounds=zeros(1,otherParameters.ids.idsBranch(end));
    
    upperBounds=caseStudyData.maxBranches*ones(1,otherParameters.ids.idsBranch(end));
else
    error('Please select a correct testebed.');
    
end
