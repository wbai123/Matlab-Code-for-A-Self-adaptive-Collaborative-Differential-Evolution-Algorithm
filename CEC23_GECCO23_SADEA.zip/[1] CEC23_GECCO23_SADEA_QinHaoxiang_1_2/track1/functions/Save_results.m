%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Save ASCII file benchmark
%
%                    11-01-2022  (last update)
%   GECAD, ISEP, Polytechnic of Porto, 2017
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Select_testbed == 1
      clear fitnessFun_riskERM,clear fitnessFun_ERM
      
        if iRuns==noRuns
            noRuns=size(ResDB,2);
%             numPeriods = 24;
            %%Calculate the score of the participant
             scenarios=size(caseStudyData);
             otherParameters_one =setOtherParameters(caseStudyData,1,Select_testbed);
             otherParameters_one.No_eval_Scenarios=scenarios(2);
             %otherParameters_one.ensPenalty=100; %This correction is done to have same impact than in the other approach
             for i=1:noRuns
                [S_val_temp,S_expected_temp,~,~,Penalties,~,solFitness_M_temp,Correct_Sol,VaR_temp,CVaR_temp,worst_Scenario_temp]=feval('fitnessFun_riskERM',ResDB(i).sol,caseStudyData, otherParameters_one);
                
                score(i,1:2)=[mean(solFitness_M_temp) std(solFitness_M_temp)];
                Scenario_cost(i,:) = solFitness_M_temp;
                solution_vector(i,:,:) =  Correct_Sol;
                
                OF(i,1) = S_val_temp;
                Fex(i,1)= S_expected_temp;
                VaR(i,1)= VaR_temp;
                CVaR(i,1)= CVaR_temp;
                
                worst_Scenario(i,1)=worst_Scenario_temp;
                
                avgScenario(i,1)=mean(solFitness_M_temp);
                minScenario(i,1)=min(solFitness_M_temp);
                maxScenario(i,1)=max(solFitness_M_temp);
                stdScenario(i,1)=std(solFitness_M_temp);
                varScenario(i,1)=var(solFitness_M_temp);

                %penalties(i,1)=sum(solPenalties_M_temp)/length(solPenalties_M_temp(1,:));
                BoundViolations(i,1) = Penalties;

             end
            %RankingIndex=sum(sum(score))/noRuns;

            %clear fitness
            for k=1:noRuns
                timeSpent(k,1)=ResDB(k).tOpt;
                fitness(k,:)=ResDB(k).fitVector(1,:);
                fitness(k,fitness(k,:)~=fitness(k,:))=0;
            end
            
            runNumber = strseq('Run ',1:noRuns);
            Table_Time = table(timeSpent,'RowNames',runNumber)
            writetable(Table_Time,sprintf('results/%d_benchmark_Time_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t','WriteRowNames',true)
             
            Table_Fitness = table(fitness,'RowNames',runNumber)
            writetable(Table_Fitness,sprintf('results/%d_benchmark_Fitness_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t','WriteRowNames',true)
            
            for k=1:noRuns
                maxIter=max(numel(find(fitness(k,:)))); %get last iteration
                for i=1:maxIter-1 % for each run calculate p convergence rate
                    pConvergenceRate(i)=fitness(k,i+1)-fitness(k,i);%log(fitness(k,i+1)/fitness(k,i))/log(i+1/i);
                end
                %bestFit(k,1)=min(fitness(k,1:maxIter));
                avgConvergenceRate(k,1)=mean(pConvergenceRate,2);
                clear pConvergenceRate
            end
            
            %Table_Scenarios = table(avgScenario,minScenario,maxScenario,stdScenario,varScenario,'RowNames',runNumber)
            %writetable(Table_Scenarios,sprintf('results/%d_benchmark_Scenarios_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t','WriteRowNames',true);

            Table_Results= table(OF,Fex,VaR,CVaR,worst_Scenario,BoundViolations,avgConvergenceRate,'RowNames',runNumber)
            writetable(Table_Results,sprintf('results/%d_benchmark_Results_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t','WriteRowNames',true);
            
            RankingIndex=mean(OF);
            PstdOF=std(OF);
            PminOF=min(OF);
            PmaxOF=max(OF);
            PvarOF=var(OF);
            
            AvgFex=mean(Fex);
            AvgVaR=mean(VaR);            
            AvgCVaR=mean(CVaR);
            AvgWorstScenario=mean(worst_Scenario);
            
            AvgTime=mean(timeSpent);

            bestFit=sum(score,2);

            caseStudy_gencode=caseStudyData(1);
            %caseStudy_gencode.genData = rmfield(caseStudy_gencode.genData,'typeEnergy');
            %caseStudy_gencode.loadData=rmfield(caseStudy_gencode.loadData,'typeConsumer');
            caseStudy_gencode.v2gData=rmfield( caseStudy_gencode.v2gData,'typeVehicle');

            validationCode=cellstr([dec2hex(round(sum(abs(bestFit))*77)),'+',num2str(sum(structfun(@(x) sum(x(:)), caseStudy_gencode.genData))+...
                sum(structfun(@(x) sum(x(:)), caseStudy_gencode.loadData))+sum(structfun(@(x) sum(x(:)), caseStudy_gencode.networkData))+...
                sum(structfun(@(x) sum(x(:)), caseStudy_gencode.storageData))+sum(structfun(@(x) sum(x(:)), caseStudy_gencode.v2gData))+...
                sum(caseStudy_gencode.storageDataInfo(:))+sum(caseStudy_gencode.v2gDataInfo(:))+...
                sum(structfun(@(x) sum(x(:)), caseStudy_gencode.marketData))+sum(sum(caseStudy_gencode.marketDataInfo))+...
                sum(structfun(@(x) sum(x(:)), caseStudy_gencode.parameterData)))]);
            Table_TrialStats = table(RankingIndex,PstdOF,PminOF,PmaxOF,PvarOF,AvgTime,validationCode)
            writetable(Table_TrialStats,sprintf('results/%d_benchmark_Summary_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t')

            %saving best solution of the 20 runs (I think)
            %[~,index] = min(OF);
            
            file=sprintf('results/%d_send2Organizers_T%d.mat',Select_algorithm,Select_testbed);
            solutions=vertcat(ResDB.sol);
            %solutions = solution_vector(index,:,:); %saving best solution
            save(file,'solutions');
        end
            State=1;
elseif Select_testbed ==2
    clear fitnessFun_transEP %name this to the fitness they named or vice-versa 
    
    if iRuns==noRuns
        noRuns=size(ResDB,2);
        otherParameters_one =setOtherParameters(caseStudyData,1,Select_testbed);
        for i=1:noRuns
            [S_val,Load_shedding,LS_Cost,Cost,Correct_sol]=feval('fitnessFun_transEP',ResDB(i).sol,caseStudyData, otherParameters_one);
            
            solution_vector(i,:) =  Correct_sol;
            OF(i,1) = S_val;
            LoadShedCost(i,1) = LS_Cost;
            investmentCost(i,1) = Cost;
        end
       
        for k=1:noRuns
            timeSpent(k,1)=ResDB(k).tOpt;
            fitness(k,:)=ResDB(k).fitVector(1,:);
            fitness(k,fitness(k,:)~=fitness(k,:))=0;
        end
        
        runNumber = strseq('Run ',1:noRuns);
        Table_Time = table(timeSpent,'RowNames',runNumber)
        writetable(Table_Time,sprintf('results/%d_benchmark_Time_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t','WriteRowNames',true)
    
        Table_Fitness = table(fitness,'RowNames',runNumber)
        writetable(Table_Fitness,sprintf('results/%d_benchmark_Fitness_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t','WriteRowNames',true)
        
        for k=1:noRuns
            maxIter=max(numel(find(fitness(k,:)))); %get last iteration
                for i=1:maxIter-1 % for each run calculate p convergence rate
                    pConvergenceRate(i)=fitness(k,i+1)-fitness(k,i);%log(fitness(k,i+1)/fitness(k,i))/log(i+1/i);
                end
                %bestFit(k,1)=min(fitness(k,1:maxIter));
                avgConvergenceRate(k,1)=mean(pConvergenceRate,2);
                clear pConvergenceRate
        end
        
        Table_Results = table(OF,LoadShedCost,investmentCost,avgConvergenceRate,'RowNames',runNumber)
        writetable(Table_Results,sprintf('results/%d_benchmark_Results_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t','WriteRowNames',true);
        
        RankingIndex=mean(OF);
        PstdOF=std(OF);
        PminOF=min(OF);
        PmaxOF=max(OF);
        PvarOF=var(OF);
        
        AvgTime=mean(timeSpent);
        
        Table_TrialStats = table(RankingIndex,PstdOF,PminOF,PmaxOF,PvarOF,AvgTime)
        writetable(Table_TrialStats,sprintf('results/%d_benchmark_Summary_T%d.txt',Select_algorithm,Select_testbed),'FileType','text','delimiter','\t')
    
        %saving best solution of the 20 runs (I think)
        [~,index] = min(OF);

        file=sprintf('results/%d_send2Organizers_T%d.mat',Select_algorithm,Select_testbed);
        solutions=vertcat(ResDB.sol);
        %solutions = solution_vector(index,:,:); %saving best solution
        save(file,'solutions');
    end
else
    error('Please select a correct testebed.');
end