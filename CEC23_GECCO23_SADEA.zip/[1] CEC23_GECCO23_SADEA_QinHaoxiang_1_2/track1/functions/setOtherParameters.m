function otherParameters = setOtherParameters(caseStudyData, size_of_population, Select_testbed)

if Select_testbed==1
        otherParameters.testBed =1;
        periods=caseStudyData(1).parameterData.numPeriods;
        % type of generator - 1 or 2 . only 2 are controlable generators
        genType2Id=find(caseStudyData(1).genData.genID(:,3)==2);
        genType1Id=find(caseStudyData(1).genData.genID(:,3)==1);
        otherParameters.genType2Id=genType2Id;
        otherParameters.genType1Id=genType1Id;
        otherParameters.ids.idsGen=1:numel(caseStudyData(1).genData.genID(:,1));
        otherParameters.ids.idsMarket=(1:size(caseStudyData(1).marketData.sellPMin,2))+otherParameters.ids.idsGen(end);
        otherParameters.ids.idsV2G=(1:numel(caseStudyData(1).v2gDataInfo(:,1)))+otherParameters.ids.idsMarket(end);
        %otherParameters.ids.idsQGen=(1:numel(caseStudyData(1).genData.genID(:,1)))+otherParameters.ids.idsGen(end);
%         otherParameters.ids.idsXGen=(1:numel(caseStudyData(1).genData.genID(:,1)))+otherParameters.ids.idsGen(end);
        otherParameters.ids.idsXGen=(1:numel(caseStudyData(1).genData.genID(:,1)))+otherParameters.ids.idsV2G(end);
%         otherParameters.ids.idsV2G=(1:numel(caseStudyData(1).v2gDataInfo(:,1)))+otherParameters.ids.idsXGen(end);
        otherParameters.ids.idsLoadDR=(1:size(caseStudyData(1).loadData.PLoad,2))+otherParameters.ids.idsXGen(end);        
%         otherParameters.ids.idsLoadDR=(1:size(caseStudyData(1).loadData.PLoad,2))+otherParameters.ids.idsV2G(end);
        otherParameters.ids.idsStorage=(1:size(caseStudyData(1).storageData.stCapacity,2))+otherParameters.ids.idsLoadDR(end);
%         otherParameters.ids.idsMarket=(1:size(caseStudyData(1).marketData.sellPMin,2))+otherParameters.ids.idsStorage(end);
        %otherParameters.ids.idsTAP=(1)+otherParameters.ids.idsMarket(end);

        %size_of_problem = otherParameters.ids.idsMarket(end)*periods;

        otherParameters.maxCapV2G=repmat(caseStudyData(1).v2gData.v2gPCap(1,:), size_of_population, 1);
        otherParameters.minUserRequestedCap=repmat(reshape(caseStudyData(1).v2gData.v2gPMinCharge', ...
            [1 numel(otherParameters.ids.idsV2G) periods]), [size_of_population 1 1]);
        otherParameters.v2gInitialState= repmat(caseStudyData(1).v2gData.v2gPPrevState(1,:), size_of_population, 1);
        otherParameters.pPrevState=repmat(reshape(caseStudyData(1).v2gData.v2gPPrevState', ...
            [1 numel(otherParameters.ids.idsV2G) periods]), [size_of_population 1 1]);

        otherParameters.stInitialState= repmat(caseStudyData(1).storageData.stPPrevState(1,:), size_of_population, 1);
        otherParameters.stPPrevState=repmat(reshape(caseStudyData(1).storageData.stPPrevState', ...
            [1 numel(otherParameters.ids.idsStorage) periods]), [size_of_population 1 1]);
        otherParameters.maxCapST=repmat(caseStudyData(1).storageData.stCapacity(1,:), size_of_population, 1);

        %otherParameters.signaling = zeros(size_of_population,size_of_problem);
        %otherParameters.signActivated=0; %Change this to one for signaling

        % set penalties
        %otherParameters.ensPenalty=300; % insufficient generation / energy not supplied
        %otherParameters.voltagePenalty=10000; % bus voltage violations
        %otherParameters.linesPenalty=10000; % rate capacity of lines violated

        otherParameters.DirectMEthod=2; %1:Direct repair %2:Binary with market compensantion %: Generators with no market compensations

         otherParameters.fnc='fitnessFun_riskERM';
         otherParameters.noSce=length(caseStudyData);
         
         otherParameters.beta =1;
         %1 - risk-averse    

         [otherParameters.lowerB,otherParameters.upperB] = setVariablesBounds(caseStudyData,otherParameters,Select_testbed);

         %otherParameters.No_eval_Scenarios=10;
         otherParameters.No_eval_Scenarios=size(caseStudyData,2); %all scnarios to calculate VaR and CVaR
        % otherParameters.otherParametersone.No_eval_Scenarios=10; %Requiered for single evaluation
         if otherParameters.No_eval_Scenarios<1
             disp('Number of scenarios to evaluate cannot be less than 1.')
             otherParameters.No_eval_Scenarios=1;
          %   otherParameters.otherParametersone.No_eval_Scenarios=1;
         end
%          otherParameters.DirectMEthod=2; %1:without direct repair 2:With direct repairs (No violations guarantee)
%          otherParameters.ensPenalty=1e2; % Penalty factor:insufficient generation / energy not supplied
elseif Select_testbed==2
    %
    otherParameters.testBed =2;
    otherParameters.ids.idsBranch = 1:size(caseStudyData.branch,1);
    otherParameters.fnc='fitnessFun_transEP'; %name this to the fitness they named or vice-versa
    otherParameters.penLoadShedding=1e9;
    
    [otherParameters.lowerB,otherParameters.upperB] = setVariablesBounds(caseStudyData,otherParameters,Select_testbed);
else 
    error('Please select a correct testebed.');
end
    
    
end

