 % available scenarios
% 1: BaseCase
% 2: 

function [caseStudyData, DB_name]=callDatabase(DB)

caseStudyData=[];

if DB==1
   load('case_study/gecco15sc');
   caseStudyData = caseStudyDataTemp;
   DB_name = 'GECCO23 - 15 Sc';
elseif DB==2
   load('case_study/geccoEXP');
   caseStudyData = caseStudyData;
   DB_name = 'GECCO23 - EXP';
else
    error('Please select a correct testebed.');
end


end
