function [VaR,CVaR,worst_Scenario] = calculate_CVaR (caseStudyData,sol_Fitness,S_expected)

%%%%%%%%%%%%%%%%%%% VaR and CVaR calculations %%%%%%%%%%%%%%%%%%
%%%%% VaR calculated using Normal Distribution Method %%%%%%%%%%

%%%%% CVaR calculated based on the paper: %%%%%%%%%%
%M. Esmaeeli, A. Kazemi, H. Shayanfar, G. Chicco, and P. Siano: "Risk-based
%planning of the distribution network structure considering uncertainties in demand and cost of energy"

Returns = sol_Fitness;
noScenarios = size(caseStudyData,2);
%pVaR = [0.05 0.01];

%TestWindow=1:SampleSize;
%VaR=zeros(length(TestWindow),1);

Mu=0;
pVaR = 0.95; 

%Zscore   = norminv(pVaR); %normal distribution

Sigma = std(Returns);
VaR = -1*(Mu-Sigma*norminv(pVaR));

%Normal95 = -Zscore(1)*Sigma;
%VaR = -Zscore*Sigma;

k=1;    
price=[];
for i = 1:noScenarios
    %if Returns(:,i) >= VaR %worst scenarios
    if Returns(:,i) >= S_expected + VaR %worst scenarios    
        %phi(i) = (Returns(:,i) - VaR) *caseStudyData(i).probScenario;
        phi(i) = (Returns(:,i) - S_expected - VaR) *caseStudyData(i).probScenario;
        index(k) = i; %saving the index of the worst scenarios
        price(k) = Returns(:,i); % cost of the worst scenarios
        k=k+1;
    else
        phi(i) = 0;
    end
    
end
aux_var=isempty(price);

if aux_var==1
    worst_Scenario = 0;
else
    worst_Scenario = max(price);
end
CVaR = VaR + ((1/(1-pVaR)) * sum(phi));   

end