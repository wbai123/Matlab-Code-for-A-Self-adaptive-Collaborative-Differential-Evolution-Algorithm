function[S_val,S_expected, profits, costs, Penalties, ExtraInfo,solFitness_M,Correct_Sol_O,VaR,CVaR,worst_Scenario] = fitnessFun_riskERM(solutions,caseStudyData,otherParameters,varargin)

%This was the previous version of the fitness function for 2019
%[solFitness_M,solPenalties_M, ExtraInfo,Correct_Sol_O,order] = fitnessFun_DER_DA(solutions,caseStudyData,otherParameters,varargin)
persistent evals
if isempty(evals)
    evals=0;
end

beta=otherParameters.beta; %risk-averse 
%penalty=100; %penalty for test
Select_testbed=otherParameters.testBed;
%varargin was added to do not require the number of evaluations
 No_eval_Scenarios=otherParameters.No_eval_Scenarios;
 %Correct_Sol=zeros(length(solutions(:,1)),length(solutions(1,:)),No_eval_Scenarios);
 Correct_Sol_O=zeros(length(solutions(:,1)),length(solutions(1,:)),No_eval_Scenarios);
 
 nParticles=length(solutions(:,1));
 
%[~,No_Scenarios]=size(caseStudyData);
%eval_this=randperm(No_Scenarios,No_eval_Scenarios);

ExtraInfo=struct([]);
for i=1:No_eval_Scenarios %all scenarios for risk
    %caseStudyData_temp=caseStudyData(eval_this(i)); %if not using all scenarios and rand selection
    caseStudyData_temp=caseStudyData(i); %changed this beacuse of the prob multiplication
    [otherParameters.lowerB,otherParameters.upperB] = setVariablesBounds(caseStudyData_temp,otherParameters,Select_testbed);
    [ExtraInfo(i).solFitness, ExtraInfo(i).solObjFun, Correct_Sol_O(:,:,i), ExtraInfo(i).otherParameters] = fitnessFun_ERM(solutions,caseStudyData_temp,otherParameters);
end

%[order,index]=sort(eval_this); %don�t need
%for i=1:length(order) %Solutions sorted in correct order
    %Correct_Sol_O(:,:,i)=Correct_Sol(:,:,index(i));
%    Correct_Sol_O(:,:,i)=Correct_Sol(:,:,i);
%end


solFitness_M=zeros(length(solutions(:,1)),No_eval_Scenarios);
for i=1:No_eval_Scenarios
    for j=1:length(solutions(:,1))
        solFitness_M(j,i)=ExtraInfo(i).solFitness(j);
    end
end

solPenalties_M=zeros(length(solutions(:,1)),No_eval_Scenarios);
for i=1:No_eval_Scenarios
    for j=1:length(solutions(:,1))
        solProfits_M(j,i)=ExtraInfo(i).solObjFun(j,1);
        solCosts_M(j,i)=ExtraInfo(i).solObjFun(j,2);
        solPenalties_M(j,i)=ExtraInfo(i).solObjFun(j,3);        
    end
end

for i=1:No_eval_Scenarios
    for j=1:length(solutions(:,1))          
        S_expected_temp(j,i) = solFitness_M(j,i) * caseStudyData(i).probScenario;
        profits_temp(j,i) = solProfits_M(j,i) * caseStudyData(i).probScenario;
        costs_temp(j,i) = solCosts_M(j,i) * caseStudyData(i).probScenario;
        Penalties_temp(j,i) = solPenalties_M(j,i) * caseStudyData(i).probScenario;
    end
end

S_expected = sum(S_expected_temp,2);
%calcular VaR e CVaR por particula
for j = 1:length(solutions(:,1))   
    [VaR(j,:),CVaR(j,:),worst_Scenario(j,:)] = calculate_CVaR(caseStudyData,solFitness_M(j,:),S_expected(j,:));
end

%S_val=(S_expected * (1-gamma)) + (CVaR * gamma); %Choose the solution with worse performance (acrescentar VaR e CVaR para cada particula)
S_val=S_expected + (CVaR * beta); %Choose the solution with worse performance (acrescentar VaR e CVaR para cada particula)
profits=sum(profits_temp,2); %multiplicar pela prob de cenario e nao fazer o mean
costs=sum(costs_temp,2);
Penalties=sum(Penalties_temp,2);

evals=evals+nParticles;
%evals=1;
if evals>5000 %changed from 75000
    error('5,000 evaluations reached. Please reduce iterations or number of particles');
end
if rem(evals,50)==0%changed from 750000
    disp(['Current evals number: ' num2str(evals)])
end
%colocar mais corridas ou mais particulas
%%esquecer custo original e minimizar CVaR
%alterar numa base de dados de 10cenarios alterar os pre�os de mercado com
%grandes varia��es

function [solFitness, solObjFun, solutions, otherParameters] = fitnessFun_ERM(solutions,caseStudyData,otherParameters)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%             Energy Resources Management fitness function
% This function evaluates meta-heuristics solutions
% The objective function is: minimize costs of DER with risk-based management.
% "solutions" contains all the variables of the optimization problem
% "solutions" is a NxD dimension matrix in which N represents the number of
% particles (i.e. in the case of PSO) and D represents the number of
% variables of the optimization problem (dimension of the particle).
% "caseStudyData" contains the data of the scenario
% "otherParameters" contains auxiliary data such as ids for the sol vector
%
%                              V3.0
%                    11-01-2022  (last update)
%                               by
%                  Jose Almeida (flzcl@isep.ipp.pt)
%   GECAD, ISEP, Polytechnic of Porto, 2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin<3
    disp('Please provide the correct number of function arguments')
    return
end
    
try
% get ids from auxiliary data in otherParameters
idsGen = otherParameters.ids.idsGen;
idsXGen=otherParameters.ids.idsXGen;
idsV2G = otherParameters.ids.idsV2G;
idsLoadDR = otherParameters.ids.idsLoadDR;
idsStorage = otherParameters.ids.idsStorage;
idsMarket = otherParameters.ids.idsMarket;

% FLC 18-oct-2018
idsgenType1Id=otherParameters.genType1Id;
idsgenType2Id=otherParameters.genType2Id;
idsgenXType1Id=idsXGen(1)-1+idsgenType1Id;
idsgenXType2Id=idsXGen(1)-1+idsgenType2Id;
%


periods = caseStudyData.parameterData.numPeriods;
nParticles = size(solutions,1);
nVariables = size(solutions,2);

% v2g batteries initial state
%v2gBalance(:,:,4) = otherParameters.v2gInitialState;%96 periods?
v2gBalance(:,:,1) = otherParameters.v2gInitialState;
% get charging efficiency for EVs form case study 
caseStudyData.v2gDataInfo(:,2)=0.9;
caseStudyData.v2gDataInfo(:,3)=0.9;
EVsChargingEfficiency=repmat(caseStudyData.v2gDataInfo(:,2)',nParticles,1);
% get discharging efficiency for EVs form case study
EVsDischargingEfficiency=repmat(caseStudyData.v2gDataInfo(:,3)',nParticles,1);
% V2G max capacity - max capacity of the EVs
maxCapV2G=otherParameters.maxCapV2G;



%EraseFLC
%solutions(1,1137)

% minimum user charge in each period
minUserRequestedCap=otherParameters.minUserRequestedCap;
% storage units initial state
%stBalance(:,:,4)=otherParameters.stInitialState;%96 periods?
stBalance(:,:,1)=otherParameters.stInitialState;
% storage units max capacity
maxCapST=otherParameters.maxCapST;
% get charging efficiency for storages form case study


%FLC 16-oct-2018 To fix efficiency of batteries
%To consider efficiency of the batteries
caseStudyData.storageDataInfo(:,3)=0.9;
caseStudyData.storageDataInfo(:,4)=0.9;

storageChargingEfficiency=repmat(caseStudyData.storageDataInfo(:,3)',nParticles,1);
% get discharging for storages efficiency form case study
storageDischargingEfficiency=repmat(caseStudyData.storageDataInfo(:,4)',nParticles,1);
% get initial state of the EVs batteries and energy demand for trips
pPrevState=otherParameters.pPrevState;
% get initial state of storage units
stPPrevState=otherParameters.stPPrevState;
% get max sell/buy capacity on markets
Max_Market=caseStudyData.marketData.sellPMax;

% get loads data
PLoad=caseStudyData.loadData.PLoad;
%loadID=caseStudyData.loadData.loadID;
PReduce=caseStudyData.loadData.PReduce;
% tolerance for power flow
%ep=1e-005;

% pre-allocation of matrix and vectors
pensSlackBus=zeros(nParticles,periods);
ENS_cost=zeros(nParticles,periods);
Excess_cost=zeros(nParticles,periods);
v2gChargeCosts=zeros(nParticles,periods);
v2gDischargeCosts=zeros(nParticles,periods);
storageChargeCosts=zeros(nParticles,periods);
storageDischargeCosts=zeros(nParticles,periods);
genCosts=zeros(nParticles,periods);
genCostsType2=zeros(nParticles,periods);
loadDRcosts=zeros(nParticles,periods);
loadIncome=zeros(nParticles,periods);
marketSellCosts=zeros(nParticles,periods);
marketBuyCosts=zeros(nParticles,periods);

% % get info data from the network
% get prices from data
genCofA=caseStudyData.genData.genCofA;
genCofB=caseStudyData.genData.genCofB;
genCofC=caseStudyData.genData.genCofC;
genPMin=caseStudyData.genData.genPMin;
genPMax=caseStudyData.genData.genPMax;
v2gMaxDischarge=caseStudyData.v2gData.v2gMaxDischarge;
v2gMaxCharge=caseStudyData.v2gData.v2gMaxCharge;
stMaxDischarge=caseStudyData.storageData.stMaxDischarge;
stMaxCharge=caseStudyData.storageData.stMaxCharge;
genID=caseStudyData.genData.genID;
CofLoad=caseStudyData.loadData.CofLoad;
CofReduce=caseStudyData.loadData.CofReduce;
v2gCofCharge=caseStudyData.v2gData.v2gCofCharge;
v2gCofDischarge=caseStudyData.v2gData.v2gCofDischarge;
stPriceCharge=caseStudyData.storageData.stPriceCharge;
stPriceDischarge=caseStudyData.storageData.stPriceDischarge;
marketPrice=caseStudyData.marketData.sellCofB;
ENSprice=3000; %(cofENS in DB)
excessPrice=100; %(cofExc in DB)
% get generators type
genType1Id=otherParameters.genType1Id;
genType2Id=otherParameters.genType2Id;
% get user-defined penalties
%ensPenalty=otherParameters.ensPenalty; % insufficient generation / energy not supplied
%if ensPenalty<1 
%    disp('Please provide the correct penalties. Penalties lower than 1 are not allowed')
%    return
%end

catch exception
    disp('Please verify if the inputs of the fit function are in correct order: (solutions,caseStudyData,otherParameters)');
    disp('Also check that the content of caseStudyData and otherParameters has been obtained using the supplied scripts');
    getReport(exception)    
end


%evals=0;

%%EraseA
% penalties_lower=sum(solutions<repmat(otherParameters.lowerB,length(solutions(:,1)),1),2);
% penalties_upper=sum(solutions>repmat(otherParameters.upperB,length(solutions(:,1)),1),2);

for i=1:periods
    
    v2gConnected=repmat(caseStudyData.v2gData.v2gConnected(i,:),length(solutions(:,1)),1);  
    
%     %EraseA
%     penalties_lower=sum(solutions<repmat(otherParameters.lowerB,length(solutions(:,1)),1),2);
%     penalties_upper=sum(solutions>repmat(otherParameters.upperB,length(solutions(:,1)),1),2);
    
    % ids for the swarm particles
    %t=i-4;
    %if(t<0)
    %  t=0;
    %end
    
    idGen=idsGen+(nVariables/periods)*(i-1);   
    idXGen=idsXGen+(nVariables/periods)*(i-1); % binary variables for generators
    idV2G=idsV2G+(nVariables/periods)*(i-1);
    idLoadDR=idsLoadDR+(nVariables/periods)*(i-1);
    idStorage=idsStorage+(nVariables/periods)*(i-1);
    idMarket = idsMarket+(nVariables/periods)*(i-1);
    
    %FLC 18-oct-2018
    idgenType1Id=idsgenType1Id+(nVariables/periods)*(i-1);
    %idgenXType1Id=idsgenXType1Id+(nVariables/numPeriods)*(i-1);
    idgenType2Id=idsgenType2Id+(nVariables/periods)*(i-1);
    %idgenXType2Id=idsgenXType2Id+(nVariables/numPeriods)*(i-1);
    %
    %solutions(:,idV2G)=0;
    %need to update bounds per scenario
%     otherParameters.lowerB(idgenType1Id)=genPMax(i,genType1Id);
%     otherParameters.upperB(idgenType1Id)=genPMax(i,genType1Id);
%     otherParameters.lowerB(idgenType2Id)=genPMin(i,genType2Id);
%     otherParameters.upperB(idgenType2Id)=genPMax(i,genType2Id);    
%     otherParameters.lowerB(idV2G)=-v2gMaxDischarge(i,:);
%     otherParameters.upperB(idV2G)=v2gMaxCharge(i,:);
%     otherParameters.lowerB(idLoadDR)=PReduce(i,:)*0;
%     otherParameters.upperB(idLoadDR)=PReduce(i,:);    
%     otherParameters.lowerB(idStorage)=-stMaxDischarge(i,:);
%     otherParameters.upperB(idStorage)=stMaxCharge(i,:);
%     otherParameters.lowerB(idMarket)=-Max_Market(i,:);
%     otherParameters.upperB(idMarket)=Max_Market(i,:);
    
    % balance of V2G batteries// lines are the particles and columns the EV
    tempSolutions=solutions(:,idV2G);
    temp1=tempSolutions>0;
    temp2=tempSolutions<0;
    try
        tempSolutions(temp1)=tempSolutions(temp1) .* EVsChargingEfficiency(temp1);
        tempSolutions(temp2)=tempSolutions(temp2) ./ EVsDischargingEfficiency(temp2);
     catch  exception
        % possible error if all vehicles are not charging or equal to 0 neither charging nor discharging
        getReport(exception)
    end
    % if period 1 (1->4?)
    %if (i==1 || i==2 || i==3 || i==4)
    if i==1
        v2gBalance(:,:,i) =  v2gBalance(:,:,i) + tempSolutions; %solutions(:,idV2G);
    % all other periods
    else
        v2gBalance(:,:,i) = v2gBalance(:,:,i-1) + tempSolutions; %solutions(:,idV2G);
        maxCapViolations = (v2gBalance(:,:,i) + pPrevState(:,:,i)) > maxCapV2G;
        if any(any(maxCapViolations))
            tempPrevState=pPrevState(:,:,i);
            tempBalance=v2gBalance(:,:,i);
            idxPrevStateToChange=tempPrevState<=0;
            idxPrevStateToChange2=tempBalance>maxCapV2G;
            maxCapViolations(idxPrevStateToChange)=0;
            maxCapViolations(idxPrevStateToChange2)=0;
            tempPrevState(maxCapViolations)= maxCapV2G(maxCapViolations)-tempBalance(maxCapViolations);
            pPrevState(:,:,i)=tempPrevState;
        end
        v2gBalance(:,:,i)=v2gBalance(:,:,i)+ pPrevState(:,:,i);
    end
    
    %% correct battery balance by direct repair method
    maxCapViolations = v2gBalance(:,:,i) > maxCapV2G;
    minCapV2G = minUserRequestedCap(:,:,i);
    minCapViolations = v2gBalance(:,:,i) < minCapV2G;
    tempBalance=v2gBalance(:,:,i);
    
    tempSolutions(minCapViolations)=(minCapV2G(minCapViolations)-(tempBalance(minCapViolations)-tempSolutions(minCapViolations)));
    tempSolutions(maxCapViolations)=(maxCapV2G(maxCapViolations)-(tempBalance(maxCapViolations)-tempSolutions(maxCapViolations)));
    tempBalance(minCapViolations)=minCapV2G(minCapViolations);
    tempBalance(maxCapViolations)=maxCapV2G(maxCapViolations);
    
    temp1=tempSolutions>0;
    temp2=tempSolutions<0;
    try
        tempSolutions(temp1)=tempSolutions(temp1) ./ EVsChargingEfficiency(temp1);
        tempSolutions(temp2)=tempSolutions(temp2) .* EVsDischargingEfficiency(temp2);
        
        %FLC 17-oct-2018
        tempSolutions= tempSolutions.*v2gConnected;      
        
    catch exception
        % possible error, e.g. dividing by zero. handle this exception
        getReport(exception)
    end
    solutions(:,idV2G) =  tempSolutions;
    v2gBalance(:,:,i)=tempBalance;
    
    
%     %EraseA
%     penalties_lower=sum(solutions<repmat(otherParameters.lowerB,length(solutions(:,1)),1),2);
%     penalties_upper=sum(solutions>repmat(otherParameters.upperB,length(solutions(:,1)),1),2);
    
    
    %% storage balance
    tempSolutions=solutions(:,idStorage);
    temp1=tempSolutions>0;
    temp2=tempSolutions<0;
    try
        tempSolutions(temp1)=tempSolutions(temp1) .* storageChargingEfficiency(temp1);
        tempSolutions(temp2)=tempSolutions(temp2) ./ storageDischargingEfficiency(temp2);
    catch exception
        % possible error, e.g. dividing by zero. handle this exception
        getReport(exception)
    end
    
    %if (i==1 || i==2 || i==3 || i==4)
    if i==1
        stBalance(:,:,i) =  stBalance(:,:,i) + tempSolutions; %solutions(:,idV2G);
    else
        stBalance(:,:,i) = stBalance(:,:,i-1) + tempSolutions; %solutions(:,idV2G);
        maxCapViolations = (stBalance(:,:,i) + stPPrevState(:,:,i)) > maxCapST;
        if any(any(maxCapViolations))
            tempPrevState=stPPrevState(:,:,i);
            tempBalance=stBalance(:,:,i);
            idxPrevStateToChange=tempPrevState<=0;
            idxPrevStateToChange2=tempBalance>maxCapST;
            maxCapViolations(idxPrevStateToChange)=0;
            maxCapViolations(idxPrevStateToChange2)=0;
            tempPrevState(maxCapViolations)= maxCapV2G(maxCapViolations)-tempBalance(maxCapViolations);
            stPPrevState(:,:,i)=tempPrevState;
        end
        stBalance(:,:,i)=stBalance(:,:,i)+ stPPrevState(:,:,i);
    end
    
    % correct battery balance by direct repair method
    maxCapViolations = stBalance(:,:,i) > maxCapST;
    minCapST = maxCapST*0;
    minCapViolations = stBalance(:,:,i) < minCapST;
    tempBalance=stBalance(:,:,i);
    
    tempSolutions(minCapViolations)=(minCapST(minCapViolations)-(tempBalance(minCapViolations)-tempSolutions(minCapViolations)));
    tempSolutions(maxCapViolations)=(maxCapST(maxCapViolations)-(tempBalance(maxCapViolations)-tempSolutions(maxCapViolations)));
    tempBalance(minCapViolations)=minCapST(minCapViolations);
    tempBalance(maxCapViolations)=maxCapST(maxCapViolations);
    
    temp1=tempSolutions>0;
    temp2=tempSolutions<0;
    try
        tempSolutions(temp1)=tempSolutions(temp1) ./ storageChargingEfficiency(temp1);
        tempSolutions(temp2)=tempSolutions(temp2) .* storageDischargingEfficiency(temp2);
    catch exception
        % possible error, e.g. dividing by zero. handle this exception
        getReport(exception)
    end
    
    solutions(:,idStorage) =  tempSolutions;
    stBalance(:,:,i)=tempBalance;
   
    
%%   energy balance
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Load to supply
    type1GensGeneration=sum(genPMax(i,genType1Id)); %Renewvable generation (Depending on the scenario)
    actualLoadMatrix = repmat(PLoad(i,:),nParticles,1)-solutions(:,idLoadDR); %Load to supply (Scenario dependent)
    
    v2gInChargeMatrix=solutions(:,idV2G)>1e-8;
    v2gInDischargeMatrix=solutions(:,idV2G)<-1e-8;
    
    stInChargeMatrix=solutions(:,idStorage)>1e-8;
    stInDischargeMatrix=solutions(:,idStorage)<-1e-8;
    
    v2gLoadMatrix = v2gInChargeMatrix.*solutions(:,idV2G);
    v2gGenMatrix = v2gInDischargeMatrix.*solutions(:,idV2G);
    
    stLoadMatrix = stInChargeMatrix.*solutions(:,idStorage);
    stGenMatrix = stInDischargeMatrix.*solutions(:,idStorage);
    
    %market sell and market buy
    marketSell=solutions(:,idMarket)>1e-8;
    marketBuy=solutions(:,idMarket)<-1e-8;
   
    marketSellMatrix = marketSell.*solutions(:,idMarket);
    marketBuyMatrix = marketBuy.*solutions(:,idMarket);
    
    loadToSupplyMatrix = sum(actualLoadMatrix,2) + sum(v2gLoadMatrix,2) - type1GensGeneration ...
        + sum(v2gGenMatrix,2) + sum(stGenMatrix,2) + sum(stLoadMatrix,2) + sum(marketSellMatrix,2) + sum(marketBuyMatrix,2);
    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % in this cycle for a power flow is run for every particle
    % network violations such as bus voltage are verified
    solutions(:,idXGen(genType1Id))=1;
    %FLC 18-Oct-2018
    solutions(:,idgenType1Id)=repmat(genPMax(i,genType1Id),nParticles,1);
%     idgenType1Id=idsgenType1Id+(nVariables/numPeriods)*(i-1);
%     idgenXType1Id=idsgenXType1Id+(nVariables/numPeriods)*(i-1);
%     idgenType2Id=idsgenType2Id+(nVariables/numPeriods)*(i-1);
%     idgenXType2Id=idsgenXType2Id+(nVariables/numPeriods)*(i-1);
    
    
    switch otherParameters.DirectMEthod
        case 1
            %% Determine if penalty is required by using binaries of individuals
            % binary variables for generatores - which are on?
            %solutions(:,idGen)=solutions(:,idGen).*round(solutions(:,idXGen));
            %FLC why you are not usign this 
            for j = 1:nParticles
                loadToSupply = loadToSupplyMatrix(j);
                GenType2_sol=sum(solutions(j,idGen(genType2Id)).*round( solutions(j,idXGen(genType2Id))),2); %
                Balance_E=abs(loadToSupply-GenType2_sol);
                pensSlackBus(j,i)=Balance_E*ensPenalty;
            end
            
        case 2 %Compensate deviations using market as possible
             busGenData=sortrows([genID(genType2Id,1),genCofB(i,genType2Id)',genPMax(i,genType2Id)'],2);
             busGenDataCumSum=cumsum(busGenData(:,3));
           
            for j = 1:nParticles
                %Generators are always set to 0 (direct repair)
               solutions(j,idGen(otherParameters.genType2Id)) =0; %This is considered as assumption from the beggining
               solutions(j,idXGen(otherParameters.genType2Id))=0;
                
                loadToSupply = loadToSupplyMatrix(j);
                gensToParticipate = find(loadToSupply > busGenDataCumSum); %Track of generators that should be turn on (if excess of energy empty)
                if loadToSupply <= busGenDataCumSum(end) && loadToSupply > 0 %If generators can be used for the correction
                    if isempty(gensToParticipate) %We just need one generator
                        solutions(j,idGen(busGenData(1,1))) = loadToSupply;
                        solutions(j,idXGen(busGenData(1,1)))=1;
                    else
                        if gensToParticipate(end)<length(busGenData(:,1)) %We need up to all but one generator
                            solutions(j,idGen(busGenData(gensToParticipate,1))) = busGenData(gensToParticipate,3);
                            solutions(j,idXGen(busGenData(gensToParticipate,1)))=1;
                            solutions(j,idGen(busGenData(gensToParticipate(end)+1,1))) = loadToSupply-sum(busGenData(gensToParticipate,3));
                            solutions(j,idXGen(busGenData(gensToParticipate(end)+1,1)))=1;
                        else %We need all generators
                            solutions(j,idGen(busGenData(gensToParticipate,1))) = busGenData(gensToParticipate,3);
                            solutions(j,idXGen(busGenData(gensToParticipate,1)))=1;
                        end
                        
                    end
                else %Compensate in the market if load to supply is < 0 (excess) or load to supply is >busGenDataCumSum(end) (deficit)
                    market_status_sell=marketSellMatrix(j,:);
                    market_status_buy=marketBuyMatrix(j,:);
                    
                    capSell=abs(market_status_buy)+ (Max_Market(i,:)-market_status_sell);
                    capBuy=market_status_sell+ (Max_Market(i,:)-abs(market_status_buy));
                    
                    if loadToSupply<0 && loadToSupply > -1*sum(capSell) %Excess of energy (Go to markets and sell as possible
                        %Codigo corregir solucion    
                         capSellCumSum=cumsum(capSell);
                         market_participation=find(-1*loadToSupply>capSellCumSum);

                        if isempty( market_participation) %One market is enough to correct the solution
                           solutions(j,idMarket(1))=solutions(j,idMarket(1))-loadToSupply;
                        else 
                            if market_participation(end)<length(idMarket) %Use up to all but one market
                                  solutions(j,idMarket( market_participation))=Max_Market(i,market_participation);
                                  solutions(j,idMarket( market_participation(end)+1))= solutions(j,idMarket(market_participation(end)+1))-loadToSupply-sum(capSell(market_participation));
                            else %Use all market capacity
                                solutions(j,idMarket(market_participation))=Max_Market(i,market_participation);
                            end

                        end
                    elseif loadToSupply>busGenDataCumSum(end) && loadToSupply < busGenDataCumSum(end)+sum(capBuy)%(deficit) %Penalty if market could not be corrected 
                     %Codigo corregir solucion
                        solutions(j,idGen(busGenData(gensToParticipate,1))) = busGenData(gensToParticipate,3);
                        if solutions(j,idGen(busGenData(gensToParticipate,1))) == 0
                            solutions(j,idXGen(busGenData(gensToParticipate,1)))=0;
                        else
                            solutions(j,idXGen(busGenData(gensToParticipate,1)))=1;
                        end
                        
                        capBuyCumSum=cumsum(capBuy);
                        market_participation=find((loadToSupply-busGenDataCumSum(end))>capBuyCumSum);
                        
                        if isempty( market_participation) %One market is enough to correct the solution
                           solutions(j,idMarket(1))=solutions(j,idMarket(1))+loadToSupply-busGenDataCumSum(end);
                        else 
                            if market_participation(end)<length(idMarket) %Use up to all but one market
                                solutions(j,idMarket( market_participation))=Max_Market(i,market_participation);
                                solutions(j,idMarket( market_participation(end)+1))= solutions(j,idMarket(market_participation(end)+1))+loadToSupply-sum(capBuy(market_participation));
                            else %Use all market capacity
                                solutions(j,idMarket(market_participation))=Max_Market(i,market_participation);
                            end

                        end
                        
                    %else %Penalty
                        %pensSlackBus(j,i)=ensPenalty; %put ENS*3000 and excess*100
                    end
                end
            end
          
        case 3 %Market variables are fix FLC 14 DEC 2018
             busGenData=sortrows([genID(genType2Id,1),genCofB(i,genType2Id)',genPMax(i,genType2Id)'],2);
             busGenDataCumSum=cumsum(busGenData(:,3));
           
            for j = 1:nParticles
                %Generators are always set to 0 (direct repair)
               solutions(j,idGen(otherParameters.genType2Id)) =0; %This is considered as assumption from the beggining
               solutions(j,idXGen(otherParameters.genType2Id))=0;
                
                loadToSupply = loadToSupplyMatrix(j);
                gensToParticipate = find(loadToSupply > busGenDataCumSum); %Track of generators that should be turn on (if excess of energy empty)
                if loadToSupply <= busGenDataCumSum(end) && loadToSupply > 0
                    if isempty(gensToParticipate)
                        solutions(j,idGen(busGenData(1,1))) = loadToSupply;
                        solutions(j,idXGen(busGenData(1,1)))=1;
                    else
                        if gensToParticipate(end)<length(busGenData(:,1))
                            solutions(j,idGen(busGenData(gensToParticipate,1))) = busGenData(gensToParticipate,3);
                            solutions(j,idXGen(busGenData(gensToParticipate,1)))=1;
                            solutions(j,idGen(busGenData(gensToParticipate(end)+1,1))) = loadToSupply-sum(busGenData(gensToParticipate,3));
                            solutions(j,idXGen(busGenData(gensToParticipate(end)+1,1)))=1;
                        else
                            solutions(j,idGen(busGenData(gensToParticipate,1))) = busGenData(gensToParticipate,3);
                            solutions(j,idXGen(busGenData(gensToParticipate,1)))=1;
                        end
                        
                    end
                else
                    pensSlackBus(j,i)=ensPenalty;
                end
            end         
    end   
        

 %%  This part can be used to add penalties when markets are restricted 
   type1GensGeneration=sum(genPMax(i,genType1Id)); %Renewvable generation (Depending on the scenario)
    actualLoadMatrix = repmat(PLoad(i,:),nParticles,1)-solutions(:,idLoadDR); %Load to supply (Scenario dependent)
    
    v2gInChargeMatrix=solutions(:,idV2G)>1e-8;
    v2gInDischargeMatrix=solutions(:,idV2G)<-1e-8;
    
    stInChargeMatrix=solutions(:,idStorage)>1e-8;
    stInDischargeMatrix=solutions(:,idStorage)<-1e-8;
    
    v2gLoadMatrix = v2gInChargeMatrix.*solutions(:,idV2G);
    v2gGenMatrix = v2gInDischargeMatrix.*solutions(:,idV2G);
    
    stLoadMatrix = stInChargeMatrix.*solutions(:,idStorage);
    stGenMatrix = stInDischargeMatrix.*solutions(:,idStorage);
    
    %market sell and market buy
    marketSell=solutions(:,idMarket)>1e-8;
    marketBuy=solutions(:,idMarket)<-1e-8;
   
    marketSellMatrix = marketSell.*solutions(:,idMarket);
    marketBuyMatrix = marketBuy.*solutions(:,idMarket);
%     
%     % calculate generation costs
%     %FLC modification
%     %solutionsGenType2=solutions(:,idGen(genType2Id));
    solutionsGenType2=solutions(:,idGen(genType2Id)).*round( solutions(:,idXGen(genType2Id))); %This should work also with direct rapair
%     
    loadToSupplyMatrix_afterRepair = sum(actualLoadMatrix,2) + sum(v2gLoadMatrix,2) - type1GensGeneration ...
        + sum(v2gGenMatrix,2) + sum(stGenMatrix,2) + sum(stLoadMatrix,2) + sum(marketSellMatrix,2) + sum(marketBuyMatrix,2)-sum(solutionsGenType2,2);
% %  
   %ajust values
   for j=1:nParticles
      if loadToSupplyMatrix_afterRepair(j,:)<1e-8 && loadToSupplyMatrix_afterRepair(j,:)>0
          loadToSupplyMatrix_afterRepair(j,:)=0;
      elseif loadToSupplyMatrix_afterRepair(j,:)<0 && loadToSupplyMatrix_afterRepair(j,:)>-1e-8
          loadToSupplyMatrix_afterRepair(j,:)=0;
      end
   end  
   
   for j=1:nParticles
       if loadToSupplyMatrix_afterRepair(j,:)>0
           ENS_cost(j,i)= loadToSupplyMatrix_afterRepair(j,:).*ENSprice;
       elseif loadToSupplyMatrix_afterRepair(j,:)<0
           Excess_cost(j,i)= -1.*loadToSupplyMatrix_afterRepair(j,:).*excessPrice;
       end
   end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FLC Erased powerflow calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Revise

    %% calculate costs/incomes
    % V2G charge costs and storage costs (incomes)
    v2gChargeCosts(:,i)=(solutions(:,idV2G)>0).*solutions(:,idV2G)*v2gCofCharge(i,:)';
    v2gDischargeCosts(:,i)=-(solutions(:,idV2G)<0).*solutions(:,idV2G)*v2gCofDischarge(i,:)';
    storageChargeCosts(:,i)=(solutions(:,idStorage)>0).*solutions(:,idStorage)*stPriceCharge(i,:)';
    storageDischargeCosts(:,i)=-(solutions(:,idStorage)<0).*solutions(:,idStorage)*stPriceDischarge(i,:)';
    
    solutionsGenType2=solutions(:,idGen(genType2Id)).*round( solutions(:,idXGen(genType2Id))); %This should work also with direct rapair
    
    genCosts(:,i)=ones(nParticles,numel(idGen))*genCofA(i,:)'+solutions(:,idGen)*genCofB(i,:)'+(solutions(:,idGen).^2)*genCofC(i,:)';
    loadDRcosts(:,i)=solutions(:,idLoadDR)*CofReduce(i,:)';
    genCostsType2(:,i)=solutionsGenType2*genCofB(i,genType2Id)';
    
    % load income - price charged from fixed loads is 0.14 cents
    loadIncome(:,i)=(repmat(PLoad(i,:),nParticles,1)-solutions(:,idLoadDR))*CofLoad(i,:)';
    % market sell and buy
    marketSellCosts(:,i)=(solutions(:,idMarket)>0).*solutions(:,idMarket)*marketPrice(i,:)';
    marketBuyCosts(:,i)=-(solutions(:,idMarket)<0).*solutions(:,idMarket)*marketPrice(i,:)';
    


end
    
    
    %if solutions are infeasible
    penalties_lower=sum(solutions<repmat(otherParameters.lowerB,length(solutions(:,1)),1),2);
    penalties_upper=sum(solutions>repmat(otherParameters.upperB,length(solutions(:,1)),1),2);

    cost_penalties_lower = penalties_lower.*1000;
    cost_penalties_upper= penalties_upper.*1000;
%     figure(1)
%     subplot(2,3,1) 
%     plot(PLoad);
%     subplot(2,3,2) 
%     plot(solutions(:,idGen));
% for i=1:periods
%     idgenType1Id=idsgenType1Id+(nVariables/periods)*(i-1);
%     idgenXType1Id=idsgenXType1Id+(nVariables/periods)*(i-1);
%  
%     for j=1:1
%     sol.GenType1(:,i,j)=solutions(1,idgenType1Id,j)';
%     sol.GenXType1(:,i,j)=solutions(1,idgenXType1Id,j)';
%     end
% end

%FLC 17-oct-2018: Checking fesiability of the solutions
%penalties_lower=sum(solutions<repmat(otherParameters.lowerB,length(solutions(:,1)),1),2);
%penalties_upper=sum(solutions>repmat(otherParameters.upperB,length(solutions(:,1)),1),2);


%convert prices in m.u./kW to m.u./MW 
%fIncome = (sum(loadIncome,2)+sum(v2gChargeCosts,2)+sum(storageChargeCosts,2) + sum(marketSellCosts,2));%*1000;
fIncome = sum(marketSellCosts,2);%*1000; % jsoares 23-10-2018 to match the model in the paper
%convert costs in m.u./kW to m.u./MW
fCosts = (sum(genCosts,2) + sum(v2gDischargeCosts,2) + sum(loadDRcosts,2) + sum(storageDischargeCosts,2)+sum(marketBuyCosts,2) + sum(ENS_cost,2)+sum(Excess_cost,2));%*1000;

solObjFun(:,1) = fIncome; 
solObjFun(:,2) = fCosts; 
%solPens =sum(pensSlackBus,2)+cost_penalties_lower+cost_penalties_upper;
solPens =cost_penalties_lower+cost_penalties_upper;
solObjFun(:,3) = solPens; 
solFitness = (-fIncome)+ ... % max profit
    fCosts+... % min costs
    solPens; % penalities
%save('')
otherParameters.genCosts = genCosts;
otherParameters.loadDRcosts = loadDRcosts;
otherParameters.v2gChargeCosts = v2gChargeCosts;
otherParameters.v2gDischargeCosts = v2gDischargeCosts;
otherParameters.v2gBalance = v2gBalance;
otherParameters.storageChargeCosts = storageChargeCosts;
otherParameters.storageDischargeCosts = storageDischargeCosts;
otherParameters.marketSellCosts = marketSellCosts;
otherParameters.marketBuyCosts = marketBuyCosts;
otherParameters.stBalance = stBalance;
otherParameters.ENSCosts = ENS_cost;
otherParameters.ExcessCosts = Excess_cost;
%otherParameters.penViolation = cost_penalties_lower+cost_penalties_upper;





